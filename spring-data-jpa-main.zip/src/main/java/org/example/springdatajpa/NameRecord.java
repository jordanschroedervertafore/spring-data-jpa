package org.example.springdatajpa;

public record NameRecord(String name) {
}
