package org.example.springdatajpa;

public interface Name {
    String getName();
}
